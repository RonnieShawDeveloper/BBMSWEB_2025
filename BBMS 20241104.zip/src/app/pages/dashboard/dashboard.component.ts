import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {AngularFirestore} from "@angular/fire/compat/firestore";
import {take} from "rxjs/operators";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit {

  offenderCount: number = 0;
  magistratesCourtCount: number = 0;
  kioskLogsCount: number = 0;

  constructor(private af: AngularFirestore) {
    // Get the count of offenders from the database
    af.collection('users').get().pipe(take(1)).subscribe((data) => {
      this.offenderCount = data.size;
    });
    af.collection('magistrateBookings').get().pipe(take(1)).subscribe((data) => {
      this.magistratesCourtCount = data.size;
    });
    af.collection('kioskCheckin').get().pipe(take(1)).subscribe((data) => {
      this.kioskLogsCount = data.size;
    });
  }

  ngOnInit(): void {

    }

}
