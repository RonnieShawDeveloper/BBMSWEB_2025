import {Component, OnDestroy, OnInit} from '@angular/core';
import {AngularFirestore} from "@angular/fire/compat/firestore";
import {take} from "rxjs";
import {Photos} from "../../models/photos";
import {Offender} from "../../models/offender";
import Swal from "sweetalert2";
import {Booking} from "../../models/booking";
import {Router} from "@angular/router";
import {Count} from "../../models/count";
import * as moment from "moment/moment";
import {Table} from "primeng/table";
import {Members} from "../../models/members";
import {KioskLogs} from "../../models/kiosk-logs";
import {reauthenticateWithCredential} from "@angular/fire/auth";
import firebase from "firebase/compat/app";
@Component({
  selector: 'app-magistrate-court',
  templateUrl: './magistrate-court.component.html',
  styleUrls: ['./magistrate-court.component.scss']
})
export class MagistrateCourtComponent implements OnInit, OnDestroy {
  defendantResults: Offender[] = [];
  selectedDefendant: Offender = {};
  selectedBooking: Booking = {};
  lastName: string = '';
  DOB: string = '';
  mainPhotoUrl = '';
  activeBookings: Booking[] = [];
  copyBookings: Booking[] = [];
  currentMember: Members = {};

  // Switches
  showSearch = true;
  showDefendantMenu = false;
  showHearing = false;
  showBooking = false;
  showSuretor: boolean = false;
  initiated = false;

  subscriptions: any[] = [];
  KioskLogs: KioskLogs[] = [];
  lateChecks: Booking[] = [];

  user = firebase.auth().currentUser;
  constructor(private af: AngularFirestore, private router: Router) {

  }

  ngOnInit(): void {
    // Get all bookings from the firestore database called 'magistrateBookings' that has a status of 'Open'
    this.subscriptions.push(this.af.collection('magistrateBookings', ref => ref.where('bookingStatus', '==', 'Open')).valueChanges().subscribe((data: Booking[]) => {
    this.copyBookings = data;
    if(this.initiated == false) {
      this.initiated = true;
      this.activeBookings = data;
    }

    }));

    // Get the current member from localstorage and store it in the currentMember variable
    this.currentMember = JSON.parse(localStorage.getItem('member') || '{}');

    // Get the Unix Timestamp in milliseconds for 1 month ago
    const oneMonthAgo = new Date().getTime() - 2592000000;
    // Get all entries from Firstore database called "kioskLogs" where "title" is equal to "AFIS ID" and the "unix" is greater than the Unix Timestamp for 1 month ago
    this.subscriptions.push(this.af.collection('kioskLogs', ref => ref
      .where('title', '==', 'AFIS ID'))
      .valueChanges().subscribe((data: KioskLogs[]) => {
      this.KioskLogs = data;
      // Loop through the kioskLogs array and remove any record from the kioskLogs array older than 1 month using the unix field as the timestamp in milliseconds
      for (let i = 0; i < this.KioskLogs.length; i++) {
        if (parseInt(this.KioskLogs[i].unix) < oneMonthAgo) {
          this.KioskLogs.splice(i, 1);
        }
      }
      // Sort the kioskLogs array by the unix field showing the newest entries first
      this.KioskLogs.sort((a, b) => (parseInt(a.unix) > parseInt(b.unix)) ? -1 : 1);
      // Loop through each activeBooking and send it to the getLastCheckin function to get the last checkin date and time
      for (let i = 0; i < this.activeBookings.length; i++) {
        this.getLastCheckin(this.activeBookings[i]);
      }
      }));

  }

  getLastCheckin(offender: Booking): string {
    if(offender.afisID == undefined || offender.afisID == null) {
      return 'AFIS NOT LINKED';
    }
    // loop through the kioskLogs array and get the last 10 characters of the description field and check to see if it equals the afisID
    for (let i = 0; i < this.KioskLogs.length; i++) {
      if (this.KioskLogs[i].description.slice(-10) == offender.afisID) {
        offender.lateCheckin = false;
        // Check if the unix date is more than 7 days ago and if so, set "late" to true
        if (parseInt(this.KioskLogs[i].unix) < new Date().getTime() - 604800000) {
          offender.lateCheckin = true;
          this.lateChecks.push(offender);
        }
        return this.humanizeDate(this.KioskLogs[i].unix)+" ("+this.KioskLogs[i].datetime + ") at " + this.KioskLogs[i].location;
      }
    }
    return 'NO CHECKIN FOUND';
  }

  enlargePhoto(photoURL: string, fName: string, lName: string) {
    // open a SWAL alert dialog and adjust the SWAL window to hold the image so it will show the image at 100% size
    Swal.fire({
      title: lName + ', ' + fName,
      html: '<img src="' + photoURL + '" style="width: 100%; height: auto;">',
      confirmButtonText: 'OK',
      showCancelButton: false,
      cancelButtonText: 'Cancel Photo',
      width: '30vw',
      heightAuto: true,
      padding: '0px',
      background: 'rgba(255,255,255,1)',
      backdrop: 'rgba(0,0,0,.8)',
      allowOutsideClick: true,
      allowEscapeKey: true,
      allowEnterKey: true,
      stopKeydownPropagation: false,
      showCloseButton: true,
      closeButtonAriaLabel: 'Close Photo',
      showConfirmButton: false,
      showDenyButton: false,
      footer: '',
      didOpen: () => {

      }
    });
  }

  clear(table: Table) {
    table.clear();
  }

  showAll() {
    this.activeBookings = this.copyBookings;
  }
  showSubmitted() {
    this.activeBookings = this.copyBookings.filter(b => b.bailStatus == 'submitted');
  }
  showGranted() {
    this.activeBookings = this.copyBookings.filter(b => b.bailStatus == 'approved');
  }
  showDenied() {
    this.activeBookings = this.copyBookings.filter(b => b.bailStatus == 'denied');
  }
  showNassau() {
    this.activeBookings = this.copyBookings.filter(b => b.court == 'Nassau');
  }
  showGrandBahamas() {
    this.activeBookings = this.copyBookings.filter(b => b.court == 'Grand Bahama');
  }
  showAbaco() {
    this.activeBookings = this.copyBookings.filter(b => b.court == 'Abaco');
  }
  showClosed() {
    this.af.collection('magistrateBookings', ref => ref.where('bookingStatus', '==', 'Closed')).valueChanges().pipe(take(1)).subscribe((closedBooks: Booking[]) => {
      this.activeBookings = closedBooks;
    });
    // this.activeBookings = this.copyBookings.filter(b => b.bookingStatus == 'Closed');
  }

  showDeleted() {
    this.activeBookings = this.copyBookings.filter(b => b.bookingStatus == 'Deleted');
  }

  showLate() {
    this.activeBookings = this.lateChecks;
  }

  doCustodyChange(booking: Booking) {
    // console.log('booking', booking);
    const firstname = booking.firstName?booking.firstName:''; // Check if the firstname is null or undefined and if so, set it to an empty string
    const lastname = booking.lastName?booking.lastName:''; // Check if the lastname is null or undefined and if so, set it to an empty string
    const middleName = booking.middleName?booking.middleName:''; // Check if the middleName is null or undefined and if so, set it to an empty string
    const fullName = firstname + ' ' + middleName + ' ' + lastname; // Combine the firstname, middleName, and lastname into a single string
    // Open a SWAL dislog with a select box to change the custody status of the selected booking and then update the booking in the firestore database called 'magistrateBookings'
    Swal.fire({
      title: 'Change Custody Status',
      input: 'select',
      inputOptions: {
        'In Holding': 'In Holding',
        'BDOCS': 'Remanded to BDOCS',
        'Released Bail': 'Released on Bail',
        'ROR': 'ROR',
        'Other':'Other'
      },
      inputPlaceholder: 'Select Custody Status',
      showCancelButton: true,
      confirmButtonText: 'Change Status',
      cancelButtonText: 'Cancel',
      reverseButtons: true
    }).then((result) => {
      if (result.value) {
        this.af.collection('magistrateBookings').doc(booking.id).update({custodyStatus: result.value});
        // Create an event in the database called BookingEvents with the event type of 'Custody Status Change' and the event description of the booking ID
        this.af.collection('BookingEvents').add({
          bookingID: booking.id,
          offenderName: fullName,
          type: 'Custody',
          title: 'Custody Status Changed',
          description: 'Custody status changed to ' + result.value + ' by ' + this.currentMember.name + ' (' + this.currentMember.id + ') at ' + new Date().toLocaleString(),
          date: new Date().toISOString(),
          unixDate: new Date().getTime().toString(),
          status: result.value,
          comment: 'This record was updated by ' + this.currentMember.name + ' (' + this.currentMember.id + ') at ' + new Date().toLocaleString() + ' and the custody status was changed to ' + result.value,

        }).then((docRef) => {
          this.subscriptions.push(this.af.collection('magistrateBookings', ref => ref.where('bookingStatus', '==', 'Open')).valueChanges().subscribe((data: Booking[]) => {
            this.copyBookings = null;
            this.activeBookings = null;
            this.copyBookings = data;
            this.activeBookings = data;
          }));
          Swal.fire(
            'Custody Status Changed',
            'The custody status has been changed and a log entry created.',
            'success'
          );
        }).catch((error) => {
          // Create a swal alert if there is an error
          Swal.fire(
            'Error',
            'There was an error updating the custody status. Please try again.',
            'error'
          );
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Custody Status Not Changed',
          'The custody status has not been changed',
          'error'
        );
      }
    });
  }

  doReopenBooking(booking: Booking) {
    // Create a Swal Dialog to confirm the reopening of the booking and if confirmed, update the booking in the firestore database called 'magistrateBookings'
    Swal.fire({
      title: 'Reopen Booking?',
      text: 'Are you sure you want to reopen this booking?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Reopen Booking',
      cancelButtonText: 'No, Cancel',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        this.af.collection('magistrateBookings').doc(booking.id).update({bookingStatus: 'Open'});
        // Create an event in the database called BookingEvents with the event type of 'Booking Reopened' and the event description of the booking ID
        this.af.collection('bookingEvents').add({
          offenderID: booking.offenderID,
          bookingID: booking.id,
          type: 'Reopened',
          title: 'Booking Reopened',
          description: 'Reopened by ' + this.currentMember.name + ' (' + this.currentMember.id + ') at ' + new Date().toLocaleString(),
          date: new Date().toISOString(),
          unixDate: new Date().getTime().toString(),
          hearingDateSet: '',
          disposition: '',
          status: 'Open',
          comment: 'This record was reopened by ' + this.currentMember.name + ' (' + this.currentMember.id + ') at ' + new Date().toLocaleString() + ' and is now open for further processing.',
          approved: false,
          denied: false,
          magistrateEmailed: false
        }).then((docRef) => {
          Swal.fire(
            'Booking Reopened',
            'The booking has been reopened and a log entry created.',
            'success'
          );
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Booking Not Reopened',
          'The booking has not been reopened',
          'error'
        );
      }
    });
  }

  doCloseBooking(booking: Booking) {
    Swal.fire({
      title: 'Reauthentication Needed',
      html: '<div class="text-danger font-weight-bold">THIS IS A SECURED FEATURE</div><br>Please re-enter your password to continue<br><input type="password" id="password" class="swal2-input" placeholder="Enter your password">',
      showCancelButton: true,
      confirmButtonText: 'Reauthenticate',
      showLoaderOnConfirm: true,

      preConfirm: () => {
        // Get the password from the input field
        const password = (document.getElementById('password') as HTMLInputElement).value;
        return password;
      }
    }).then((result) => {
      if(result.isConfirmed) {
        // console.log('Password', result);
        // Reauthenticate the user using the email and password
        reauthenticateWithCredential(this.user, firebase.auth.EmailAuthProvider.credential(this.user.email, result.value)).then(() => {
          //console.log('Reauthenticated');

          // open a SWAL alert dialog to confirm the deletion of the booking and if confirmed, delete the booking from the firestore database called 'magistrateBookings'
          Swal.fire({
            title: 'Close Booking?',
            text: 'Are you sure you want to close this booking?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, Close Booking',
            cancelButtonText: 'No, Cancel',
            reverseButtons: true
          }).then((result) => {
            if (result.isConfirmed) {
              this.af.collection('magistrateBookings').doc(booking.id).update({bookingStatus: 'Closed'});
              // Create an event in the database called BookingEvents with the event type of 'Booking Deleted' and the event description of the booking ID
              this.af.collection('bookingEvents').doc().set({
                offenderID: booking.offenderID,
                bookingID: booking.id,
                type: 'Closed',
                title: 'Booking Closed',
                description: 'Closed by ' + this.currentMember.name + ' (' + this.currentMember.id + ') at ' + new Date().toLocaleString(),
                date: new Date().toISOString(),
                unixDate: new Date().getTime().toString(),
                hearingDateSet: '',
                disposition: '',
                status: 'Close',
                comment: 'This record was closed by ' + this.currentMember.name + ' (' + this.currentMember.id + ') at ' + new Date().toLocaleString() + ' and is set for deletion.',
                approved: false,
                denied: false,
                magistrateEmailed: false
              }).then((docRef) => {
                Swal.fire(
                  'Booking Closed',
                  'The booking has been closed and a log entry created.',
                  'success'
                );
              });
            } else if (result.dismiss === Swal.DismissReason.cancel) {
              Swal.fire(
                'Booking Not Closed',
                'The booking has not been Closed.',
                'error'
              );
            }
          });
        } ).catch((error) => {
          // Create a Swal message letting the user know the booking event was not saved successfully
          Swal.fire({
            title: 'ERROR WITH YOUR PASSWORD',
            text: 'Your password was incorrect',
            icon: 'error',
            confirmButtonText: 'OK'
          });
        });
      }
    });
  }

  doDeleteBooking(booking: Booking) {
    Swal.fire({
      title: 'Reauthentication Needed',
      html: '<div class="text-danger font-weight-bold">THIS IS A SECURED FEATURE</div><br>Please re-enter your password to continue<br><input type="password" id="password" class="swal2-input" placeholder="Enter your password">',
      showCancelButton: true,
      confirmButtonText: 'Reauthenticate',
      showLoaderOnConfirm: true,

      preConfirm: () => {
        // Get the password from the input field
        const password = (document.getElementById('password') as HTMLInputElement).value;
        return password;
      }
    }).then((result) => {
      if(result.isConfirmed) {
        // console.log('Password', result);
        // Reauthenticate the user using the email and password
        reauthenticateWithCredential(this.user, firebase.auth.EmailAuthProvider.credential(this.user.email, result.value)).then(() => {
          //console.log('Reauthenticated');

          // open a SWAL alert dialog to confirm the deletion of the booking and if confirmed, delete the booking from the firestore database called 'magistrateBookings'
          Swal.fire({
            title: 'Delete Booking?',
            text: 'Are you sure you want to delete this booking? This action cannot be undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, Delete Booking',
            cancelButtonText: 'No, Cancel',
            reverseButtons: true
          }).then((result) => {
            if (result.isConfirmed) {
              this.af.collection('magistrateBookings').doc(booking.id).update({bookingStatus: 'Deleted'});
              // Create an event in the database called BookingEvents with the event type of 'Booking Deleted' and the event description of the booking ID
              this.af.collection('bookingEvents').add({
                offenderID: booking.offenderID,
                bookingID: booking.id,
                type: 'Deleted',
                title: 'Booking Closed and set for Deletion',
                description: 'Deleted by ' + this.currentMember.name + ' (' + this.currentMember.id + ') at ' + new Date().toLocaleString(),
                date: new Date().toISOString(),
                unixDate: new Date().getTime().toString(),
                hearingDateSet: '',
                disposition: '',
                status: 'Deleted',
                judge: booking.judge,
                judgeID: booking.judgeID,
                comment: 'This record was deleted by ' + this.currentMember.name + ' (' + this.currentMember.id + ') at ' + new Date().toLocaleString() + ' and is set for deletion.',
                approved: false,
                denied: false,
                magistrateEmailed: false
              });


              Swal.fire(
                'Booking Deleted',
                'The booking has been marked for Deletion and a log entry created.',
                'success'
              );
            } else if (result.dismiss === Swal.DismissReason.cancel) {
              Swal.fire(
                'Booking Not Deleted',
                'The booking has not been deleted',
                'error'
              );
            }
          });
        } ).catch((error) => {
          // Create a Swal message letting the user know the booking event was not saved successfully
          Swal.fire({
            title: 'ERROR WITH YOUR PASSWORD',
            text: 'Your password was incorrect',
            icon: 'error',
            confirmButtonText: 'OK'
          });
        });
      }
    });



  }
  getAge(age: string|number) {
    // get the current age in years from the age provided as a string or number in the format of 'YYYY-MM-DD'
    const today = new Date();
    const birthDate = new Date(age);
    let ageYears = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())){
      ageYears--;
    }
    return ageYears;
  }

  humanizeDate(unixDate: string) {
    // Check to see if the unixDate is null or undefined and return an empty string if it is
    if (unixDate == null || unixDate == undefined) {
      return "Date Not Set";
    }
    let unixTimestamp = parseInt(unixDate);
    // Convert the unixTimestamp to milliseconds if needed
    if (unixTimestamp.toString().length < 13) {
      unixTimestamp = unixTimestamp * 1000;
    }
    return moment(unixTimestamp).fromNow();
  }

  // Convert unixDate to localDate for display
  convertUnixDate(unixDate: string) {
    // Check to see if the unixDate is null or undefined and return an empty string if it is
    if (unixDate == null || unixDate == undefined) {
      return "Date Not Set";
    }
    let unixTimestamp = parseInt(unixDate);
    // Convert the unixTimestamp to milliseconds if needed
    if (unixTimestamp.toString().length < 13) {
      unixTimestamp = unixTimestamp * 1000;
    }

    const date = new Date(unixTimestamp);

    const month = date.toLocaleString('en-US', { month: 'long' });
    const day = date.getDate();
    const year = date.getFullYear();
    let hour = date.getHours();
    const minute = date.getMinutes();

    const amOrPm = hour < 12 ? 'AM' : 'PM';
    hour = hour % 12 || 12; // Convert hour to 12-hour format

    const formattedDate = `${month} ${day}, ${year} ${hour}:${minute.toString().padStart(2, '0')} ${amOrPm}`;

    return formattedDate;
  }

  getPhoto() {
    // Loop through each Defendant in the defendantResults array
    for (let i = 0; i < this.defendantResults.length; i++) {
      // Get the defendant's ID
      const id = this.defendantResults[i].spn;
      this.defendantResults[i].mainPhoto = '';
      // console.log('id', id);
      // Get the defendant's photo from the firestore database called 'user' where the id is equal to the defendant's id
      this.subscriptions.push(this.af.collection('photos', ref => ref.where('offenderID', '==', id)).valueChanges().pipe(take(1)).subscribe((data: Photos[]) => {
        // Check to see if any photos were found and if not, set the defendant's mainPhoto to '/assets/img/users/default-user.jpg' and move on to next defendant
        if (data.length == 0) {
          this.defendantResults[i].mainPhoto = '/assets/img/users/default-user.jpg';
          return;
        }
        // console.log('data', data);
        // Loop through the 'photos' array in the 'data' object and find the photo with 'photoMain' equal to true and set the 'defendantResults[i].mainPhoto' to the photoUrl of that photo
        for (let j = 0; j < data[0].photos.length; j++) {
          if (data[0].photos[j].photoMain == true) {
            this.defendantResults[i].mainPhoto = data[0].photos[j].photoUrl;
            // console.log('mainPhoto', this.defendantResults[i].mainPhoto);
          }
        }
        // Check if a main photo was found and if not, use the photo found in '/assets/img/users/default-user.jpg'
        if (this.defendantResults[i].mainPhoto == '') {
          this.defendantResults[i].mainPhoto = '/assets/img/users/default-user.jpg';
        }
      }));
    }

  } // end getPhoto

  doSelect(book: Booking) {
    this.selectedBooking = book;
    this.showSearch = false;
    this.showBooking = true;
  }

  createBooking() {
    this.showBooking = true;
    this.showHearing = false;
    this.showSearch = false;
  }

  doSuretorReport() {
    this.showSuretor = true;
    this.showSearch = false;
  }

  closeHearing($event) {
    this.selectedBooking = {};
    this.selectedDefendant = {};
    this.showBooking = false;
    this.mainPhotoUrl = '';
    this.defendantResults = [];
    this.showSearch = true;
    this.showHearing = false;
    for (let i = 0; i < this.subscriptions.length; i++) {
      this.subscriptions[i].unsubscribe();
    }
    // Get all bookings from the firestore database called 'magistrateBookings' that has a status of 'Open'
    this.subscriptions.push(this.af.collection('magistrateBookings', ref => ref.where('bookingStatus', '==', 'Open')).valueChanges().subscribe((data: Booking[]) => {
      this.activeBookings = data;
    }));
  }

  ngOnDestroy(): void {
    // Go through all subscriptions and unsubscribe
    for (let i = 0; i < this.subscriptions.length; i++) {
      this.subscriptions[i].unsubscribe();
    }
  }
}
